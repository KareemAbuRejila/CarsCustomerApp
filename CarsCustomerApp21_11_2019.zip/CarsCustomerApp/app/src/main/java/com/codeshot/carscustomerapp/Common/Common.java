package com.codeshot.carscustomerapp.Common;


import com.codeshot.carscustomerapp.Remote.IGoogleAPI;
import com.codeshot.carscustomerapp.Remote.RetrofitClient;

public class Common {
    private static final String baseURL="https://maps.googleapis.com";
    public static IGoogleAPI getGoogleAPI(){
        return RetrofitClient.getClient(baseURL).create(IGoogleAPI.class);
    }

    public static final String driversAvailable_tbl="DriversAvailable";
    public static final String drivers_tbl="Drivers";
    public static final String riders_tbl="Riders";
    public static final String pickUpRequest_tbl="PickUpRequests";
}

package com.codeshot.carscustomerapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.Manifest;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.codeshot.carscustomerapp.Common.Common;
import com.codeshot.carscustomerapp.Models.Driver;
import com.codeshot.carscustomerapp.Remote.IGoogleAPI;
import com.codeshot.carscustomerapp.nav_fragments.ProfileFragment;
import com.codeshot.carscustomerapp.starting.LoginActivity;
import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.firebase.geofire.GeoQuery;
import com.firebase.geofire.GeoQueryEventListener;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.JointType;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.maps.model.SquareCap;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener,
        OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        LocationListener {

    //View
    private Toolbar toolbar;
    private ActionBarDrawerToggle toggle;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private SupportMapFragment mapFragment;
    //Firebase
    private FirebaseAuth mAuth;
    private String currentUserID;
    private DatabaseReference rootRef, ridersRef, myRef;
    private GeoFire geoFire;
    //Map
    private GoogleMap mMap;
    //PlayService
    private int My_PERMISSION_REQUEST_CODE = 7000;
    private int PLAY_SERVICE_RES_REQUEST = 7001;

    private LocationRequest mLocationRequest;
    private GoogleApiClient mGoogleApiClient;
    private Location mLastLocation;

    private int UPDATE_INTERVAL = 5000;
    private int FASTEST_INTERVAL = 3000;
    private int DISPLACEMENT = 10;

    private Marker mMarker;

    //Car Animation
    private List<LatLng> polyLineList;
    private Marker carMarker;
    private float v;
    private double lat, lng;
    private Handler handler;
    private LatLng startPosition, endPosition, currentPosition, destinationPosition;
    private int index, next;
    private Button btnGo;
    private EditText edtPlace;
    private AutocompleteSupportFragment placeAutocompleteFragment, destinationPlacesLaceAutocompleteFragment;
    private String destination;
    private PolylineOptions polylineOptions, blackPolyLineOpetions;
    private Polyline blackPolyLine, grayPolyLine;

    private IGoogleAPI mServices;
    private boolean isDriverFound = false;
    String driverID="";
    private int radius = 1;//1 Km
    private int distance = 1; //3 Km
    private static final int LIMIT=3;


    private ImageView imgExpandable;
    private BottomSheetRiderFragment bottomSheetRiderFragment;
    private Button btnPickUpRequest;

    private GeoLocation driverLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);
        initializations();
        setDrawer();
        polyLineList = new ArrayList<>();
        placeAutocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NonNull Place place) {

                destination = place.getName().toString();
                destination = destination.replace(" ", "+");
                Log.i("Destination Location : ", destination);
                destinationPosition = place.getLatLng();
//                getDirections();
            }

            @Override
            public void onError(@NonNull Status status) {
                Toast.makeText(HomeActivity.this, status.getStatus().toString(), Toast.LENGTH_SHORT).show();

            }
        });
        setUpLocation();
        mServices = Common.getGoogleAPI();
        imgExpandable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetRiderFragment.show(getSupportFragmentManager(), bottomSheetRiderFragment.getTag());
            }
        });
        btnPickUpRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (driverLocation==null)
                requestPickUpHere(currentUserID);
                else getDirections(driverLocation);
            }
        });
    }

    private void requestPickUpHere(String currentUserID) {
        if (!isDriverFound){
            DatabaseReference requestsRef = rootRef.child(Common.pickUpRequest_tbl);
            GeoFire geoFire = new GeoFire(requestsRef);
            geoFire.setLocation(currentUserID, new GeoLocation(mLastLocation.getLatitude(), mLastLocation.getLongitude()));
            if (mMarker.isVisible())
                mMarker.remove();
            mMarker = mMap.addMarker(new MarkerOptions()
                    .title("PickUp Here")
                    .snippet("snippet of PickUp")
                    .position(new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude()))
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
            mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                @Override
                public boolean onMarkerClick(Marker marker) {
                    marker.showInfoWindow();
                    return true;
                }
            });
            btnPickUpRequest.setText("Getting your PickUp");
//        btnPickUpRequest.setEnabled(false);

            findDriver();
        }

    }

    private void findDriver() {

        DatabaseReference driversLRef = rootRef.child(Common.driversAvailable_tbl);
        GeoFire gfDrivers = new GeoFire(driversLRef);

        GeoQuery geoQuery = gfDrivers.queryAtLocation(new GeoLocation(mLastLocation.getLatitude(), mLastLocation.getLongitude())
                , radius);
        geoQuery.removeAllListeners();
        geoQuery.addGeoQueryEventListener(new GeoQueryEventListener() {
            @Override
            public void onKeyEntered(String key, GeoLocation location) {

                //if found
                if (!isDriverFound) {
                    isDriverFound = true;
                    driverID = key;
                    btnPickUpRequest.setText("CALL DRIVER");
                    Toast.makeText(HomeActivity.this, " " + key, Toast.LENGTH_SHORT).show();
                    driverLocation=location;
                }

            }

            @Override
            public void onKeyExited(String key) {
                btnPickUpRequest.setText("PICKUP REQUEST");
                btnPickUpRequest.setEnabled(true);
            }

            @Override
            public void onKeyMoved(String key, GeoLocation location) {
                driverLocation=location;

            }

            @Override
            public void onGeoQueryReady() {
                //if still not found driver, increase distance
                if (!isDriverFound) {
                    radius++;
                    findDriver();
                }
            }

            @Override
            public void onGeoQueryError(DatabaseError error) {


            }
        });
        if (!isDriverFound){
            btnPickUpRequest.setEnabled(true);
            btnPickUpRequest.setText("PICKUP REQUEST");
        }
    }

    private void initializations() {
        //Init View
        toolbar = findViewById(R.id.toolBarHomeActivity);
        setSupportActionBar(toolbar);
        drawerLayout = findViewById(R.id.drawer_customer_layout);
        navigationView = findViewById(R.id.navigationViewOfHomeActivity);
        toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        imgExpandable = findViewById(R.id.imgExpandable);
        bottomSheetRiderFragment = BottomSheetRiderFragment.newInstance("Rider bottom sheet");
        btnPickUpRequest = findViewById(R.id.btnPickUpRequest);

        //Map Activity
        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), getResources().getString(R.string.googleDirectionKey));
        }
        placeAutocompleteFragment = (AutocompleteSupportFragment) getSupportFragmentManager().findFragmentById(R.id.placeAutocompleteFragment);
        placeAutocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.LAT_LNG, Place.Field.NAME));
        destinationPlacesLaceAutocompleteFragment = (AutocompleteSupportFragment) getSupportFragmentManager().findFragmentById(R.id.destinationPlacesLaceAutocompleteFragment);
        destinationPlacesLaceAutocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.LAT_LNG, Place.Field.NAME));

        rootRef = FirebaseDatabase.getInstance().getReference();
        ridersRef = rootRef.child(Common.riders_tbl);
        mAuth = FirebaseAuth.getInstance();
        if (mAuth.getCurrentUser() != null)
            currentUserID = mAuth.getCurrentUser().getUid();
        myRef = ridersRef.child(currentUserID);
        geoFire = new GeoFire(myRef);
    }

    private void setDrawer() {
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        //start main fragment

    }

    private void getDirections(GeoLocation driverLocation) {

        currentPosition = new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude());

        String requestAPI = null;
        try {
            requestAPI = "https://maps.googleapis.com/maps/api/directions/json?" +
                    "mode=driving&" +
                    "transit_routing_preference=less_driving&" +
                    "origin=" + currentPosition.latitude + "," + currentPosition.longitude + "&" +
                    "destination=" + driverLocation.latitude + "," + driverLocation.longitude+ "&" +
                    "key=" + getResources().getString(R.string.googleDirectionKey);
            Log.i("Direction Request API", requestAPI);
            mServices.getPath(requestAPI)
                    .enqueue(new Callback<String>() {
                        @Override
                        public void onResponse(Call<String> call, Response<String> response) {
                            try {
                                JSONObject jsonObject = new JSONObject(response.body().toString());
                                JSONArray jsonArray = jsonObject.getJSONArray("routes");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject route = jsonArray.getJSONObject(i);
                                    JSONObject poly = route.getJSONObject("overview_polyline");
                                    String polyline = poly.getString("points");
                                    polyLineList = decodePoly(polyline);
                                }
                                //Adjusting bounds
                                LatLngBounds.Builder builder = new LatLngBounds.Builder();
                                for (LatLng latLng : polyLineList) {
                                    builder.include(latLng);
                                    LatLngBounds bounds = builder.build();
                                    CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngBounds(bounds, 2);
                                    mMap.animateCamera(cameraUpdate);

                                    polylineOptions = new PolylineOptions();
                                    polylineOptions.color(Color.RED);
                                    polylineOptions.width(5);
                                    polylineOptions.startCap(new SquareCap());
                                    polylineOptions.endCap(new SquareCap());
                                    polylineOptions.jointType(JointType.ROUND);
                                    polylineOptions.addAll(polyLineList);
                                    grayPolyLine = mMap.addPolyline(polylineOptions);

                                    blackPolyLineOpetions = new PolylineOptions();
                                    blackPolyLineOpetions.color(Color.BLACK);
                                    blackPolyLineOpetions.width(5);
                                    blackPolyLineOpetions.startCap(new SquareCap());
                                    blackPolyLineOpetions.endCap(new SquareCap());
                                    blackPolyLineOpetions.jointType(JointType.ROUND);
                                    blackPolyLineOpetions.addAll(polyLineList);
                                    blackPolyLine = mMap.addPolyline(blackPolyLineOpetions);

                                    mMap.addMarker(new MarkerOptions()
                                            .position(polyLineList.get(polyLineList.size() - 1))
                                            .title("PickUp Location"));

                                    //Animations
                                    ValueAnimator polyLineAnimator = ValueAnimator.ofInt(0, 100);
                                    polyLineAnimator.setDuration(2000);
                                    polyLineAnimator.setInterpolator(new LinearInterpolator());
                                    polyLineAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                                        @Override
                                        public void onAnimationUpdate(ValueAnimator animation) {
                                            List<LatLng> points = grayPolyLine.getPoints();
                                            int percentValue = (int) animation.getAnimatedValue();
                                            int size = points.size();
                                            int newPoint = (int) (size * (percentValue / 100.0f));
                                            List<LatLng> p = points.subList(0, newPoint);
                                            blackPolyLine.setPoints(p);
                                        }
                                    });
                                    polyLineAnimator.start();

//                                    carMarker = mMap.addMarker(new MarkerOptions().position(currentPosition)
//                                            .flat(true)
//                                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.car)));
//
//                                    handler = new Handler();
//                                    index = -1;
//                                    next = 1;
//                                    handler.postDelayed(getDrawPathRunnable(), 3000);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onFailure(Call<String> call, Throwable t) {
                            Toast.makeText(HomeActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();

                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private List decodePoly(String encoded) {

        List poly = new ArrayList();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;

        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;

            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;
            LatLng p = new LatLng((double) lat / 1E5, (double) lng / 1E5);
            poly.add(p);

        }

        return poly;
    }

    private Runnable getDrawPathRunnable() {
        Runnable drawPathRunnable = new Runnable() {
            @Override
            public void run() {
                if (index < polyLineList.size() - 1) {
                    index++;
                    next = index + 1;
                }
                if (index < polyLineList.size() - 1) {
                    startPosition = polyLineList.get(index);
                    endPosition = polyLineList.get(next);
                }
                final ValueAnimator valueAnimator = ValueAnimator.ofFloat(0, 1);
                valueAnimator.setDuration(3000);
                valueAnimator.setInterpolator(new LinearInterpolator());
                valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override
                    public void onAnimationUpdate(ValueAnimator animation) {
                        v = valueAnimator.getAnimatedFraction();
                        lng = v * endPosition.longitude + (1 - v) * startPosition.longitude;
                        lat = v * endPosition.latitude + (1 - v) * startPosition.latitude;
                        LatLng newPos = new LatLng(lat, lng);
                        carMarker.setPosition(newPos);
                        carMarker.setAnchor(0.5f, 0.5f);
                        carMarker.setRotation(getBearing(startPosition, newPos));
                        mMap.moveCamera(CameraUpdateFactory.newCameraPosition(
                                new CameraPosition.Builder()
                                        .target(newPos)
                                        .zoom(15.5f)
                                        .build()
                        ));
                    }
                });
                valueAnimator.start();
                handler.postDelayed(this, 3000);

            }
        };
        return drawPathRunnable;
    }

    private float getBearing(LatLng startPosition, LatLng endPosition) {
        double lat = Math.abs(startPosition.latitude - endPosition.latitude);
        double lng = Math.abs(startPosition.longitude - endPosition.longitude);

        if (startPosition.latitude < endPosition.latitude && startPosition.longitude < endPosition.longitude)
            return (float) (Math.toDegrees(Math.atan(lng / lat)));
        else if (startPosition.latitude >= endPosition.latitude && startPosition.longitude < endPosition.longitude)
            return (float) ((90 - Math.toDegrees(Math.atan(lng / lat))) + 90);
        else if (startPosition.latitude >= endPosition.latitude && startPosition.longitude >= endPosition.longitude)
            return (float) (Math.toDegrees(Math.atan(lng / lat)) + 180);
        else if (startPosition.latitude < endPosition.latitude && startPosition.longitude >= endPosition.longitude)
            return (float) ((90 - Math.toDegrees(Math.atan(lng / lat))) + 270);
        return -1;
    }

    private void setUpLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            //Request runtime permission
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, My_PERMISSION_REQUEST_CODE);
        } else {
            if (checkPlayServices()) {
                buildGoogleApiClient();
                createLocationRequest();
                displayLocation();

            }
        }

    }

    private void displayLocation() {

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (mLastLocation != null) {

            final double latitude = mLastLocation.getLatitude();
            final double longitude = mLastLocation.getLongitude();
            //Add Marker
            if (mMarker != null) mMarker.remove();//Remove already mMarker

            mMarker = mMap.addMarker(new MarkerOptions()
                    .position(new LatLng(latitude, longitude))
                    .title("You"));
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latitude, longitude), 15.0f));


//            //Draw animation rotate mMarker
//            rotateMarker(mMarker, -360, mMap);
//            Snackbar.make(mapFragment.getView(), "You are Online", Snackbar.LENGTH_SHORT).show();

            loadAllAvailableDriver();

            Log.d("Kareem",String.format("Your Location was changed : %f / %f",latitude,longitude));
        }else
            Log.d("Kareem","Can not get your Location");

    }

    private void loadAllAvailableDriver() {

        //Load all available Driver in distance 3 km;
        DatabaseReference driversLRef = rootRef.child(Common.driversAvailable_tbl);
        GeoFire gfDrivers = new GeoFire(driversLRef);

        GeoQuery geoQuery = gfDrivers.queryAtLocation(new GeoLocation(mLastLocation.getLatitude(), mLastLocation.getLongitude())
                , distance);
        geoQuery.removeAllListeners();
        geoQuery.addGeoQueryEventListener(new GeoQueryEventListener() {
            Marker dMarker = null;
            DatabaseReference driversRef=rootRef.child(Common.drivers_tbl);
            @Override
            public void onKeyEntered(String key, final GeoLocation location) {

                //Use key to get email from table Drivers
                //Table Driver is table when driver register account and update info
                //Just open your to check this table name




                driversRef.child(key).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        //Because Rider and Driver model is same properties
                        Driver driver=dataSnapshot.getValue(Driver.class);

                        //Add Driver to Map
                        dMarker=mMap.addMarker(new MarkerOptions()
                        .position(new LatLng(location.latitude,location.longitude))
                        .title(driver.getUserName())
                        .flat(true)
                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.car))
                        );
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }

            @Override
            public void onKeyExited(String key) {
                dMarker.remove();
            }

            @Override
            public void onKeyMoved(String key, final GeoLocation location) {
                if (dMarker!=null) dMarker.remove();
                driversRef.child(key).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        //Because Rider and Driver model is same properties
                        Driver driver=dataSnapshot.getValue(Driver.class);

                        //Add Driver to Map
                        dMarker=mMap.addMarker(new MarkerOptions()
                                .position(new LatLng(location.latitude,location.longitude))
                                .title(driver.getUserName())
                                .flat(true)
                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.car))
                        );
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }

            @Override
            public void onGeoQueryReady() {
                //if still not found driver, increase distance
                if (distance<=LIMIT){
                    //distance for just for 3 km
                    distance++;
                    loadAllAvailableDriver();
                }
            }

            @Override
            public void onGeoQueryError(DatabaseError error) {
                Toast.makeText(HomeActivity.this,error.getMessage(),Toast.LENGTH_LONG).show();

            }
        });

    }

    private void createLocationRequest() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(UPDATE_INTERVAL);
        mLocationRequest.setFastestInterval(FASTEST_INTERVAL);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setSmallestDisplacement(DISPLACEMENT);
    }

    private void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();
    }

    private boolean checkPlayServices() {
        int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                GooglePlayServicesUtil.getErrorDialog(resultCode, this, PLAY_SERVICE_RES_REQUEST).show();
            } else {
                Toast.makeText(this, "This Device is not supported", Toast.LENGTH_LONG).show();
            }
            return false;
        }
        return true;
    }

    private void rotateMarker(final Marker marker, final int i, GoogleMap mMap) {
        final Handler handler = new Handler();
        long start = SystemClock.uptimeMillis();
        final float startRotation = marker.getRotation();
        final long duration = 1500;

        final Interpolator interpolator = new LinearInterpolator();
        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis();
                float t = interpolator.getInterpolation((float) elapsed / duration);
                float rot = t * i * (1 - t) * startRotation;
                marker.setRotation(-rot > 180 ? rot / 2 : rot);
                if (t < 1.0) {
                    handler.postDelayed(this, 16);
                }
            }
        });
    }

    private void startLocationUpdates() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);

        }
    }

    private void stopLocationUpdates() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (checkPlayServices()) {
                buildGoogleApiClient();
                createLocationRequest();
                displayLocation();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_home_activity_drawer, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        switch (id) {

            case R.id.nav_LogOut:
                mAuth.signOut();
                sendToLoginActivity();
                break;

        }
        return true;
    }

    private void sendToLoginActivity() {
        startActivity(new Intent(HomeActivity.this, LoginActivity.class));
        finish();
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
//
            case R.id.nav_Profile:
                Toast.makeText(this, "Profile", Toast.LENGTH_SHORT).show();
                getSupportFragmentManager().beginTransaction().replace(R.id.contentOfHomeActivity, new ProfileFragment()).commit();
                break;
            case R.id.nav_PaymentHistory:
                Toast.makeText(this, "PaymentHistory", Toast.LENGTH_SHORT).show();
                break;
            case R.id.nav_RideHistory:
                Toast.makeText(this, "RideHistory", Toast.LENGTH_SHORT).show();
                break;
            case R.id.nav_Notifications:
                Toast.makeText(this, "Notifications", Toast.LENGTH_SHORT).show();
                break;
            case R.id.nav_Help:
                Toast.makeText(this, "Help", Toast.LENGTH_SHORT).show();
                break;
            case R.id.nav_LogOut:
                mAuth.signOut();
                sendToLoginActivity();
                break;


        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        mMap.setTrafficEnabled(false);
        mMap.setIndoorEnabled(false);
        mMap.setBuildingsEnabled(false);
        mMap.getUiSettings().setZoomControlsEnabled(true);

        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setAllGesturesEnabled(true);
        mMap.setInfoWindowAdapter(new CustomInfoWindow(this));
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        displayLocation();
        startLocationUpdates();
    }

    @Override
    public void onConnectionSuspended(int i) {
        mGoogleApiClient.connect();
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Toast.makeText(this, connectionResult.getErrorMessage(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onLocationChanged(Location location) {
        mLastLocation = location;
        displayLocation();
    }


    @Override
    protected void onStart() {
        super.onStart();
//        loadDrivers();
    }

    private void loadDrivers() {
        DatabaseReference driversRef = rootRef.child(Common.driversAvailable_tbl);
        GeoFire gfDrivers = new GeoFire(driversRef);
        final List<Driver> drivers = new ArrayList<>();
        driversRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot diver : dataSnapshot.getChildren()) {
                        final Driver driver = diver.getValue(Driver.class);
                        drivers.add(driver);
                        mMap.addMarker(new MarkerOptions()
                                .position(new LatLng(37.4219283, -122.084))
                                .title(driver.getUserName())
                        );


                    }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
